// Physical memory allocator, for user processes,
// kernel stacks, page-table pages,
// and pipe buffers. Allocates whole 4096-byte pages.

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "riscv.h"
#include "defs.h"
#include "proc.h"

void freerange(void *pa_start, void *pa_end);

extern char end[]; // first address after kernel.
                   // defined by kernel.ld.

typedef struct frDesc {
  uint64 *entry;
  uint32 refBits;
  uint8 free;
}frDesc;

struct {
  struct spinlock lock;
  struct frDesc *descriptors;
  char* frames;
  uint64 framesNum;
} kmem;


uint64 NumOfFrames(){
    uint64 ret =  ((uint64)PHYSTOP - (uint64)end + 1)/(sizeof(frDesc) + PGSIZE);
    ret--;
    return ret;
}

char* InitFrames(uint64 numOfFrames){
    char* ret = (char*)((char*)end + sizeof(frDesc)*numOfFrames);
    ret = (char*) PGROUNDUP((uint64)ret);
    return ret;
}

void
kinit()
{
  initlock(&kmem.lock, "kmem");
  kmem.framesNum = NumOfFrames();
  kmem.frames = InitFrames(kmem.framesNum);
  //MOZDA TREBA SMANJITI BROJ OKVIRA
  kmem.descriptors = (frDesc*)end;
  freerange((void*)kmem.frames, (void*)PHYSTOP);
}

void
freerange(void *pa_start, void *pa_end)
{
  char *p;
  p = (char*)PGROUNDUP((uint64)pa_start);
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    kfree(p);
}

// Free the page of physical memory pointed at by pa,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)


void FreeDesc(uint64 i){
    kmem.descriptors[i].entry = 0;
    kmem.descriptors[i].free = 1;
    kmem.descriptors[i].refBits = 0;
}

/*
Uzimanje frameEntry
 uint64 i = ((uint64)pa - (uint64)kmem.frames)/PGSIZE;
 kmem.desc[i]

*/

frDesc* getDes(void* mem){
    uint64 retIn = ((uint64)mem - (uint64)kmem.frames) / PGSIZE;
    return kmem.descriptors  + retIn;
}

char* getAddr(struct frDesc* desc){
    char* addr = (desc-kmem.descriptors)*PGSIZE + (char*)kmem.frames;
    return addr;
}
struct frDesc* victim() {
    acquire(&kmem.lock);
    //printf("Greska Victim");

    uint16 min = 0;
    //int ind = -1;
    struct frDesc* ret = 0;
    //struct frDesc* pomocna = 0;
    for (uint64 i = 0; i < kmem.framesNum; i++) {
        if (kmem.descriptors[i].entry && !kmem.descriptors[i].free) {
            if(!(*(kmem.descriptors[i].entry) & PTE_X)){
                if (*(kmem.descriptors[i].entry) & PTE_U) {
                    //pomocna = &kmem.descriptors[i];
                    if (kmem.descriptors[i].refBits < min){
                        ret = &kmem.descriptors[i];
                        //ind = i;
                        min = kmem.descriptors[i].refBits;
                    }
                }
            }
        }
    }
    release(&kmem.lock);
/*
    if (!ret) {
        ret = pomocna;
    }*/
    if(!ret){
        //printf("GRESKA VICTIM");
        return 0;
    }


    //vise nije validna
    *(ret->entry) |= PTE_D;
    *(ret->entry) &= ~PTE_V;

    //izbaciti je
    return ret;
}
void
kfree(void *pa)
{

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
  acquire(&kmem.lock);
  uint64 i = ((uint64)pa - (uint64)kmem.frames)/PGSIZE;
  //resetovanje deskriptora
  FreeDesc(i);
  release(&kmem.lock);
}

char* evictPage(){
    frDesc* zrtva = victim();    //uzimamo zrtvu za izbacivanje
    if(!zrtva) {
        extern int noYield;
        noYield= 0;
        return 0;
    }
    acquire(&kmem.lock);
    char* addr = getAddr(zrtva);
    //printf("%d", addr);
    int blckNum = getfreeblocknum();      //uzimamo slobodan blok
    if(blckNum == -1){
        *(zrtva->entry) |= PTE_V;
        *(zrtva->entry) &= ~PTE_D;
    }
    char * ret = addr;
    uint64 mask = ~(0xffffffffff << 10);
    *(zrtva->entry) &= mask;
    *(zrtva->entry) |= (blckNum << 10);
    zrtva->refBits = 0xff000000; //da ne bi odmah bio najbolji kandidat
    uchar data[1024];
    zrtva->entry = 0;
    release(&kmem.lock);
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 1024; j++) {
            data[j] = *addr;
            addr++;
        }
        write_block(blckNum, (uchar*)data, 1);  //uvek se radi busy wait
        //printf("%d ", blckNum);
        blckNum++;
    }
    //printf("%d\t", zrtva->entry);

    sfence_vma();
    return ret;
}


// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{

  char *ret = 0;
  acquire(&kmem.lock);

  for(uint64 i = 0; i< kmem.framesNum; i++){
      if(kmem.descriptors[i].free){
          ret = (char*)kmem.frames;
          //TREBA DA SE POMERI ZA I*SIZE
          ret += i*PGSIZE;
          //vise nije slobodan
          kmem.descriptors[i].free = 0;
          break;
      }
  }

  release(&kmem.lock);

  if(ret)
    memset((char*)ret, 5, PGSIZE); // fill with junk
  else{
      //printf("DOSLO DO EVICT");
      ret = evictPage();
  }
  return (void*)ret;
}


void updateRefBits(){
    acquire(&kmem.lock);
    for(int i=0; i< kmem.framesNum; i++){
        if(kmem.descriptors[i].entry){
            if(!kmem.descriptors[i].free){
                if(*(kmem.descriptors[i].entry) & PTE_U){
                    if(!(*(kmem.descriptors[i].entry) & PTE_D)){
                        kmem.descriptors[i].refBits >>=1;
                        if((*(kmem.descriptors[i].entry) & PTE_A)){
                            //AKO SMO PRISTUPALI STRANICI
                            kmem.descriptors[i].refBits |= (1<<31);
                            *(kmem.descriptors[i].entry) &= ~PTE_A;

                        }
                    }

                }
            }
        }
    }
    release(&kmem.lock);
    //printf("PROVERA")
}

void postavljanjePokazivaca(uint64* pte, uint64 pa){
    acquire(&kmem.lock);
    frDesc* desc= getDes((void*)pa);
    desc->entry = pte;
    release(&kmem.lock);
}

void swapIn(void* mem, uint64* pte){
    acquire(&kmem.lock);
    uint32 block = (*pte) >> 10;
    uchar data[1024];
    uchar * frame = (uchar *)mem;
    release(&kmem.lock);
    for (int i = 0; i < 4; i++) {
        //uvek se radi busy wait
        read_block(block, (uchar*)data, 1);
        for (int j = 0; j < 1024; j++) {
            *frame = data[j];
            frame++;
        }
        //printf("%d ", block);
        block++;
    }
    acquire(&kmem.lock);
    uint64 flags = PTE_FLAGS(*pte);
    //postavi flegova ne one koji su bili ranije i postavi da je validna
    //i skloni D da nije na disku
    *pte = (PA2PTE((uint64)mem) | flags | PTE_V) & ~PTE_D;
    release(&kmem.lock);
}

void pomocnaFunkcija(void* mem, uint64* pte){
    frDesc * desc= getDes(mem);
    desc->entry = pte;
}

uint handlePageFault(uint64 va){
    uint64* pte = walk(myproc()->pagetable, va, 0);
    // 0 ne alocira ako ne postoji
    //printf("U HANDLE: %d\t", pte);
    if(!(pte)){
        //printf("Nema pte handle");
        return 0;
    }

    if (*pte & PTE_D){
        void* mem = kalloc();
        if(!mem) return 0;
        //nem ana disku mesta
        swapIn(mem, pte);
        pomocnaFunkcija(mem, pte);
        return 1;
    }

    //printf("GRESKA HANDLE");
    return 0;

}


